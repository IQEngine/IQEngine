import{j as t,R as e}from"./index-7e1729fd.js";const a=()=>t.jsx(e.Fragment,{});export{a as default};
//# sourceMappingURL=TailwindStyle-7357755a.js.map
