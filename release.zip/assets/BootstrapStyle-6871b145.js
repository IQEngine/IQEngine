import{j as t,R as o}from"./index-7e1729fd.js";const n=()=>t.jsx(o.Fragment,{});export{n as default};
//# sourceMappingURL=BootstrapStyle-6871b145.js.map
